fruits = ("Orange")
print(type(fruits))